function reg()
{
    var username=document.getElementById("p1").value;
    var email=document.getElementById("p2").value;
    var pass=document.getElementById("p3").value;
    var pass2=document.getElementById("p4").value;


if(username==''){
    alert('Please enter your username');
}
else if(email==''){
    alert('Please enter your email');
}
else if(pass=''){
    alert('Please enter your password')
}
else if(pass2=''){
    alert('Please confirm your password')
}
else if(pass != pass2){
    alert('Password not matched')
}
else{
    alert('Account created successfully');

}
}
